<div>
	
	<a href="index.php" <?php echo "" ? 'class="actived"' : ''; ?>>首页</a>
	&nbsp;|&nbsp;
	<a href="list.php">商品列表</a>
	&nbsp;|&nbsp;
	<a href="introduce.php">简介</a>
</div>