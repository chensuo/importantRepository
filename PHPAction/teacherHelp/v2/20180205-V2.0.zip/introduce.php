<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>简介</title>
</head>
<body>
	<?php 
		include_once("inc/header.php");
	 ?>
	<hr>
	简介
</body>
</html>