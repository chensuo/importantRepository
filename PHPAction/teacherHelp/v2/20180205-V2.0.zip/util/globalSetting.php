<?php 


define("IMAGE_URL_ROOT" , "http://192.168.12.100/LibraryWebapi/images/");