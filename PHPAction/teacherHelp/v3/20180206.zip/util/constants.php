<?php 


define("CODE_NO_AUTH" , 403);
define("MESSAGE_NO_AUTH" , "用户尚未登录");

define("CODE_PARAM_INVALID" , 102);
define("MESSAGE_PARAM_INVALID" , "参数无效");

define("CODE_BOOK_NOT_EXISTS" , 103);
defind("MESSAGE_BOOK_NOT_EXISTS" , "图书信息不存在");